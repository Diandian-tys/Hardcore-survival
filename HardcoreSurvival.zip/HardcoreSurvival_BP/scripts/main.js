import { world, system, Difficulty, EquipmentSlot, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

// Localization Dictionary
const LANG = {
  zh: {
    title: "§c§l硬核生存 - 语言设置",
    body: "§f欢迎来到《硬核生存》模组！\n\n§7核心机制：\n§c• 生命上限强制压制为 2 颗心 (4点血量)\n§6• 夜晚丧尸与小白全面强化至困难甚至炼狱级\n§b• 水中溺水极易触发【抽筋】状态，无法移动只能扑腾\n\n§e请选择您的界面语言（随时可输入 !lang 或 !语言 切换）：",
    btnZh: "§a简体中文 (Chinese)",
    btnEn: "§bEnglish (英文)",
    selected: "§a[硬核生存] §f已切换为 §e简体中文§f！祝你好运，活下去……",
    crampTitle: "§c§l⚠ 抽筋了！",
    crampAction: "§c§l[抽筋状态] §e肌肉剧烈痉挛！无法游动，正在下沉扑腾！",
    crampRecover: "§a[硬核生存] §f抽筋缓解了，快游向水面！",
    nightWarnHard: "§4§l[黑夜降临] §c丧尸与小白已进入【困难狂暴】状态！",
    nightWarnNightmare: "§4§l[炼狱之夜] §c检测到困难模式！丧尸与小白已突破极限，进入【超困难·炼狱】状态！"
  },
  en: {
    title: "§c§lHardcore Survival - Language",
    body: "§fWelcome to Hardcore Survival!\n\n§7Core Mechanics:\n§c• Max Health locked to 2 Hearts (4 HP)\n§6• Zombies & Skeletons escalate to Hard/Nightmare at night\n§b• Drowning in water triggers [Cramp] — immobilized & flailing\n\n§eSelect your language (type !lang anytime to switch):",
    btnZh: "§a简体中文 (Chinese)",
    btnEn: "§bEnglish (English)",
    selected: "§a[Hardcore Survival] §fLanguage set to §eEnglish§f! Good luck surviving...",
    crampTitle: "§c§l⚠ CRAMP!",
    crampAction: "§c§l[CRAMPED] §eSevere leg cramp! You can't swim, only flail!",
    crampRecover: "§a[Hardcore Survival] §fThe cramp subsided. Swim up now!",
    nightWarnHard: "§4§l[Night Falls] §cZombies & Skeletons escalated to HARD fury!",
    nightWarnNightmare: "§4§l[Infernal Night] §cHard difficulty detected! Zombies & Skeletons escalated BEYOND HARD!"
  }
};

function getPlayerLang(player) {
  const saved = player.getDynamicProperty("hc_lang");
  return saved === "en" ? "en" : "zh";
}

function showLanguageMenu(player) {
  const current = getPlayerLang(player);
  const dict = LANG[current];
  const form = new ActionFormData()
    .title(dict.title)
    .body(dict.body)
    .button(LANG.zh.btnZh)
    .button(LANG.en.btnEn);

  form.show(player).then((response) => {
    if (response.canceled) {
      if (!player.getDynamicProperty("hc_lang")) {
        player.setDynamicProperty("hc_lang", "zh");
      }
      return;
    }
    const chosen = response.selection === 0 ? "zh" : "en";
    player.setDynamicProperty("hc_lang", chosen);
    player.sendMessage(LANG[chosen].selected);
    player.playSound("random.orb", { volume: 1.0, pitch: 1.0 });
  }).catch(() => {});
}

world.afterEvents.playerSpawn.subscribe((event) => {
  const { player, initialSpawn } = event;
  enforceTwoHearts(player);
  if (initialSpawn && !player.getDynamicProperty("hc_lang_prompted")) {
    player.setDynamicProperty("hc_lang_prompted", true);
    system.runTimeout(() => {
      if (player.isValid()) {
        showLanguageMenu(player);
      }
    }, 30);
  }
});

world.beforeEvents.chatSend.subscribe((event) => {
  const msg = event.message.trim().toLowerCase();
  if (msg === "!lang" || msg === "!language" || msg === "!语言" || msg === "！语言") {
    event.cancel = true;
    const player = event.sender;
    system.run(() => {
      if (player.isValid()) {
        showLanguageMenu(player);
      }
    });
  }
});

// 1. Force 2 Hearts (4 HP) Cap
function enforceTwoHearts(player) {
  try {
    const healthComp = player.getComponent("minecraft:health");
    if (healthComp && healthComp.currentValue > 4) {
      healthComp.setCurrentValue(4);
    }
    if (player.getEffect("health_boost")) {
      player.removeEffect("health_boost");
    }
    if (player.getEffect("absorption")) {
      player.removeEffect("absorption");
    }
  } catch (e) {}
}

// 2. Nighttime Zombie & Skeleton Escalation
let lastNightAnnounced = false;

function isNightTime() {
  const time = world.getTimeOfDay();
  return time >= 13000 && time <= 23000;
}

function getWorldDifficultySafe() {
  try {
    return world.getDifficulty();
  } catch (e) {
    return Difficulty.Normal;
  }
}

function enhanceNightMob(entity, isInfernalHard) {
  if (!entity || !entity.isValid()) return;
  const typeId = entity.typeId;
  if (typeId !== "minecraft:zombie" && typeId !== "minecraft:skeleton") return;

  if (isInfernalHard) {
    // Beyond Hard ("超困难 / 炼狱模式")
    entity.addEffect("strength", 60, { amplifier: 3, showParticles: true }); // Strength IV
    entity.addEffect("speed", 60, { amplifier: 1, showParticles: false }); // Speed II
    entity.addEffect("resistance", 60, { amplifier: 1, showParticles: false }); // Resistance II
    entity.addEffect("fire_resistance", 60, { amplifier: 0, showParticles: false });
  } else {
    // Elevated to Hard Mode standard+ regardless of Peaceful/Easy/Normal
    entity.addEffect("strength", 60, { amplifier: 1, showParticles: false }); // Strength II
    entity.addEffect("speed", 60, { amplifier: 0, showParticles: false }); // Speed I
    entity.addEffect("resistance", 60, { amplifier: 0, showParticles: false }); // Resistance I
  }

  if (!entity.getDynamicProperty("hc_night_buffed")) {
    entity.setDynamicProperty("hc_night_buffed", true);
    try {
      const equip = entity.getComponent("minecraft:equippable");
      if (equip) {
        if (isInfernalHard) {
          equip.setEquipment(EquipmentSlot.Head, new ItemStack("minecraft:diamond_helmet", 1));
          equip.setEquipment(EquipmentSlot.Chest, new ItemStack("minecraft:iron_chestplate", 1));
          if (typeId === "minecraft:zombie") {
            equip.setEquipment(EquipmentSlot.Mainhand, new ItemStack("minecraft:diamond_sword", 1));
          }
        } else {
          equip.setEquipment(EquipmentSlot.Head, new ItemStack("minecraft:iron_helmet", 1));
          if (typeId === "minecraft:zombie") {
            equip.setEquipment(EquipmentSlot.Mainhand, new ItemStack("minecraft:iron_sword", 1));
          }
        }
      }
      const hp = entity.getComponent("minecraft:health");
      if (hp) {
        hp.resetToMaxValue();
      }
    } catch (e) {}
  }
}

// 3. Water Cramp ("抽筋") Mechanic
function processWaterCramp(player, dict) {
  let crampTicks = player.getDynamicProperty("hc_cramp_ticks") || 0;
  const inWater = player.isInWater;

  let isSubmergedOrDrowning = false;
  try {
    const breath = player.getComponent("minecraft:breathable");
    if (breath && breath.airSupply < breath.totalSupply) {
      isSubmergedOrDrowning = true;
    }
  } catch (e) {}

  let headInWater = false;
  try {
    const headLoc = player.getHeadLocation();
    const block = player.dimension.getBlock({
      x: Math.floor(headLoc.x),
      y: Math.floor(headLoc.y),
      z: Math.floor(headLoc.z)
    });
    if (block && (block.typeId === "minecraft:water" || block.typeId === "minecraft:flowing_water")) {
      headInWater = true;
    }
  } catch (e) {}

  const activelyDrowning = headInWater || isSubmergedOrDrowning;

  if (inWater && activelyDrowning && crampTicks <= 0) {
    if (Math.random() < 0.22) {
      crampTicks = 100 + Math.floor(Math.random() * 81);
      player.setDynamicProperty("hc_cramp_ticks", crampTicks);
      player.onScreenDisplay.setTitle(dict.crampTitle, {
        stayDuration: 40,
        fadeInDuration: 5,
        fadeOutDuration: 10,
        subtitle: dict.crampAction
      });
      player.playSound("mob.player.hurt_drown", { volume: 1.0, pitch: 0.75 });
    }
  }

  if (crampTicks > 0) {
    crampTicks -= 10;
    if (crampTicks <= 0) {
      player.setDynamicProperty("hc_cramp_ticks", 0);
      player.onScreenDisplay.setActionBar(dict.crampRecover);
      return;
    }
    player.setDynamicProperty("hc_cramp_ticks", crampTicks);

    // Apply "Cramp" status potion effects
    player.addEffect("slowness", 20, { amplifier: 255, showParticles: true });
    player.addEffect("mining_fatigue", 20, { amplifier: 2, showParticles: false });
    player.addEffect("weakness", 20, { amplifier: 1, showParticles: false });
    player.addEffect("nausea", 45, { amplifier: 0, showParticles: false });

    player.onScreenDisplay.setActionBar(dict.crampAction);

    if (inWater) {
      try {
        const vel = player.getVelocity();
        const flailX = (Math.random() - 0.5) * 0.14;
        const flailZ = (Math.random() - 0.5) * 0.14;
        const sinkY = vel.y > -0.06 ? -0.07 : vel.y;
        player.applyImpulse({
          x: flailX - vel.x * 0.7,
          y: sinkY - vel.y,
          z: flailZ - vel.z * 0.7
        });
      } catch (e) {}
    }
  }
}

system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    if (!player.isValid()) continue;
    enforceTwoHearts(player);
  }
}, 5);

system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    if (!player.isValid()) continue;
    const dict = LANG[getPlayerLang(player)];
    processWaterCramp(player, dict);
  }
}, 10);

system.runInterval(() => {
  const night = isNightTime();
  const diff = getWorldDifficultySafe();
  const isInfernalHard = diff === Difficulty.Hard;

  if (night && !lastNightAnnounced) {
    lastNightAnnounced = true;
    for (const player of world.getAllPlayers()) {
      if (!player.isValid()) continue;
      const dict = LANG[getPlayerLang(player)];
      player.sendMessage(isInfernalHard ? dict.nightWarnNightmare : dict.nightWarnHard);
      player.playSound("mob.wither.spawn", { volume: 0.6, pitch: 1.3 });
    }
  } else if (!night && lastNightAnnounced) {
    lastNightAnnounced = false;
  }

  if (night) {
    const dimensions = ["overworld", "nether", "the_end"];
    for (const dimId of dimensions) {
      try {
        const dim = world.getDimension(dimId);
        const zombies = dim.getEntities({ type: "minecraft:zombie" });
        for (const z of zombies) {
          enhanceNightMob(z, isInfernalHard);
        }
        const skeletons = dim.getEntities({ type: "minecraft:skeleton" });
        for (const s of skeletons) {
          enhanceNightMob(s, isInfernalHard);
        }
      } catch (e) {}
    }
  }
}, 20);
